
        # self.registr=QHBoxLayout()
        # self.regis_label=QLabel("Registratsiya")
        # self.regis_label.setStyleSheet("text-align: center;")
        # self.registr.addWidget(self.regis_label)